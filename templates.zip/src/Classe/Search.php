<?php
namespace App\Classe;
class  Search {

    /*
     * @var Departement[]
     */
    public $village=[];


    /*
     * @var string
     */
    public $type;
}
