<?php
namespace App\Classe;
class  SearchTypeActe {

    /*
     * @var Type[]
     */
    public $type=[];

}
